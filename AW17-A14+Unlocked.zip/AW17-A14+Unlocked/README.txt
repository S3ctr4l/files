- Unblocked advanced menu


flashing:

use the Sleep Bug !
Unpack the archive and copy the into C: HD root place !
Then open Comand Promt with Admin Rights (CLI window C:\), put your laptop
into Sleep Mode and then Wake-Up It, atger this execute these comands from
CLI window :

fptw64 -f bios.bin -bios


******************************************************************************

donation paypal - biosmod8@gmail.com
or
BTC - 175WaQRqyk1eCmsDdRLSnttRVg7Jn7Ppgn

Any donation is much appreciated

******************************************************************************

WARNING
do not disconnect the intel video card!!!!!
no change size videomemory!!!! 